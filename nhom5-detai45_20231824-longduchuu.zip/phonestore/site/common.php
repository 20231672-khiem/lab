<?php
// ============================================
// FILE: common.php - Dùng chung cho website
// ============================================

/**
 * Lấy danh sách menu items
 */
function getMenuItems() {
    return [
        'home' => [
            'url' => 'home.php',
            'title' => '🏠 Trang chủ',
            'description' => 'Trang chủ website'
        ],
        'about' => [
            'url' => 'about.php',
            'title' => 'ℹ️ Giới thiệu',
            'description' => 'Thông tin về chúng tôi'
        ],
        'contact' => [
            'url' => 'contact.php',
            'title' => '📞 Liên hệ',
            'description' => 'Liên hệ với chúng tôi'
        ]
    ];
}

/**
 * Render header HTML với BANNER ĐẸP
 */
function renderHeader($pageTitle = 'Trang chủ') {
    // Đặt header cho UTF-8
    header('Content-Type: text/html; charset=UTF-8');
    ?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8'); ?> - Lab 01 IT3220</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    </head>
    <body>
        <!-- BANNER LỚN Ở ĐẦU TRANG -->
        <div class="hero-banner">
            <div class="banner-overlay"></div>
            <div class="banner-content">
                <div class="banner-logo">
                    <i class="fas fa-code"></i>
                </div>
                <h1 class="banner-title">LAB 01 - TỔNG QUAN WEB & THIẾT LẬP MÔI TRƯỜNG</h1>
                <p class="banner-subtitle">Môn học: Lập trình Web - IT3220 | Đại học Công nghệ Đông Á</p>
                <div class="banner-stats">
                    <div class="stat-item">
                        <i class="fas fa-check-circle"></i>
                        <span class="stat-value">Bài 1</span>
                        <span class="stat-label">Hello PHP</span>
                    </div>
                    <div class="stat-item">
                        <i class="fas fa-check-circle"></i>
                        <span class="stat-value">Bài 2</span>
                        <span class="stat-label">3 Trang Web</span>
                    </div>
                    <div class="stat-item">
                        <i class="fas fa-check-circle"></i>
                        <span class="stat-value">Bài 3</span>
                        <span class="stat-label">GET/POST</span>
                    </div>
                    <div class="stat-item">
                        <i class="fas fa-check-circle"></i>
                        <span class="stat-value">Bài 4</span>
                        <span class="stat-label">DevTools</span>
                    </div>
                </div>
            </div>
        </div>

        <header class="site-header">
            <div class="container header-container">
                <div class="logo">
                    <h1><i class="fas fa-code"></i> LAB 01 - IT3220</h1>
                    <p>Lập trình Web - Đại học Công nghệ Đông Á</p>
                </div>
                <nav class="main-nav">
                    <?php renderNavigation(); ?>
                </nav>
            </div>
        </header>
        
        <main class="main-content">
            <div class="container">
    <?php
}

/**
 * Render navigation menu
 */
function renderNavigation($currentPage = 'home') {
    $menuItems = getMenuItems();
    ?>
    <ul>
        <?php foreach($menuItems as $key => $item): ?>
            <li class="<?php echo ($key == $currentPage) ? 'active' : ''; ?>">
                <a href="<?php echo $item['url']; ?>">
                    <?php echo htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8'); ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php
}

/**
 * Render footer
 */
function renderFooter($groupInfo = null) {
    // Thông tin mặc định
    if (!$groupInfo) {
        $groupInfo = [
            'group_name' => 'Nhóm của bạn',
            'class' => 'IT3220',
            'course' => 'Lập trình Web',
            'semester' => 'Học kỳ 2024-2025',
            'members' => ['Thành viên 1', 'Thành viên 2', 'Thành viên 3']
        ];
    }
    ?>
            </div>
        </main>
        
        <!-- FOOTER VỚI BANNER NHỎ -->
        <footer class="site-footer">
            <div class="footer-banner">
                <div class="container">
                    <div class="footer-banner-content">
                        <i class="fas fa-rocket"></i>
                        <span>Hoàn thành Lab 01 - Sẵn sàng cho Lab 02!</span>
                        <i class="fas fa-rocket"></i>
                    </div>
                </div>
            </div>
            
            <div class="container">
                <div class="footer-content">
                    <div class="footer-info">
                        <h3><i class="fas fa-users"></i> Thông tin nhóm</h3>
                        <p><strong><i class="fas fa-user-friends"></i> Nhóm:</strong> <?php echo htmlspecialchars($groupInfo['group_name'], ENT_QUOTES, 'UTF-8'); ?></p>
                        <p><strong><i class="fas fa-graduation-cap"></i> Lớp:</strong> <?php echo htmlspecialchars($groupInfo['class'], ENT_QUOTES, 'UTF-8'); ?></p>
                        <p><strong><i class="fas fa-book"></i> Môn học:</strong> <?php echo htmlspecialchars($groupInfo['course'], ENT_QUOTES, 'UTF-8'); ?></p>
                        <p><strong><i class="fas fa-calendar-alt"></i> Học kỳ:</strong> <?php echo htmlspecialchars($groupInfo['semester'], ENT_QUOTES, 'UTF-8'); ?></p>
                        
                        <?php if(isset($groupInfo['members'])): ?>
                        <p style="margin-top: 10px;">
                            <strong><i class="fas fa-user"></i> Thành viên:</strong><br>
                            <?php 
                            $members = array_map(function($member) {
                                return htmlspecialchars($member, ENT_QUOTES, 'UTF-8');
                            }, $groupInfo['members']);
                            echo implode(', ', $members); 
                            ?>
                        </p>
                        <?php endif; ?>
                    </div>
                    
                    <div class="footer-links">
                        <h3><i class="fas fa-link"></i> Liên kết nhanh</h3>
                        <ul>
                            <?php foreach(getMenuItems() as $item): ?>
                            <li>
                                <a href="<?php echo $item['url']; ?>">
                                    <i class="fas fa-arrow-right"></i> <?php 
                                    $title = str_replace(['🏠', 'ℹ️', '📞'], '', $item['title']);
                                    echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); 
                                    ?>
                                </a>
                            </li>
                            <?php endforeach; ?>
                            <li><a href="../hello.php"><i class="fas fa-code"></i> Bài 1: Hello PHP</a></li>
                            <li><a href="../get_demo.php"><i class="fas fa-paper-plane"></i> Bài 3: GET Demo</a></li>
                            <li><a href="../register.php"><i class="fas fa-edit"></i> Bài 3: POST Demo</a></li>
                            <li><a href="../info.php"><i class="fas fa-info-circle"></i> PHP Info</a></li>
                        </ul>
                    </div>
                </div>
                
                <div class="footer-bottom">
                    <p>
                        <i class="fas fa-copyright"></i> <?php echo date('Y'); ?> - Bộ môn Công nghệ phần mềm, Khoa CNTT, Đại học Công nghệ Đông Á
                    </p>
                    <p style="margin-top: 5px; font-size: 0.85em;">
                        <i class="fas fa-server"></i> Server Time: <?php echo date('H:i:s d/m/Y'); ?>
                    </p>
                </div>
            </div>
        </footer>
        
        <script>
        // Thêm hiệu ứng cho menu
        document.addEventListener('DOMContentLoaded', function() {
            const navLinks = document.querySelectorAll('.main-nav a');
            navLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    navLinks.forEach(l => l.classList.remove('clicked'));
                    this.classList.add('clicked');
                });
            });
            
            // Hiệu ứng scroll cho header
            window.addEventListener('scroll', function() {
                const header = document.querySelector('.site-header');
                if (window.scrollY > 50) {
                    header.style.boxShadow = '0 4px 30px rgba(0, 0, 0, 0.2)';
                    header.style.padding = '1rem 0';
                } else {
                    header.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.15)';
                    header.style.padding = '1.5rem 0';
                }
            });
        });
        </script>
    </body>
    </html>
    <?php
}

// Hàm helper để tạo breadcrumb
function renderBreadcrumb($items) {
    if(empty($items)) return;
    
    echo '<nav class="breadcrumb">';
    echo '<ul>';
    foreach($items as $index => $item) {
        $isLast = ($index === count($items) - 1);
        echo '<li>';
        if(!$isLast && isset($item['url'])) {
            echo '<a href="' . $item['url'] . '">' . htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') . '</a>';
            echo ' <span class="separator">›</span> ';
        } else {
            echo '<strong>' . htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') . '</strong>';
        }
        echo '</li>';
    }
    echo '</ul>';
    echo '</nav>';
}
?>