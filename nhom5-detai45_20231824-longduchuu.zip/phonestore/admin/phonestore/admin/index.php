<?php
// admin/index.php
session_start();
require_once '../includes/config.php';

// Kiểm tra đăng nhập và quyền admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../pages/login.php");
    exit();
}

// Lấy thống kê
$stats = [];
$sql = "SELECT COUNT(*) as total FROM users";
$result = mysqli_query($conn, $sql);
$stats['users'] = mysqli_fetch_assoc($result)['total'];

$sql = "SELECT COUNT(*) as total FROM products";
$result = mysqli_query($conn, $sql);
$stats['products'] = mysqli_fetch_assoc($result)['total'];

$sql = "SELECT COUNT(*) as total FROM orders";
$result = mysqli_query($conn, $sql);
$stats['orders'] = mysqli_fetch_assoc($result)['total'];

$sql = "SELECT SUM(total) as total FROM orders";
$result = mysqli_query($conn, $sql);
$stats['revenue'] = mysqli_fetch_assoc($result)['total'] ?: 0;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - PhoneStore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            position: fixed;
            width: 250px;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 15px 20px;
            display: block;
            border-bottom: 1px solid #495057;
        }
        .sidebar a:hover {
            background: #495057;
        }
        .sidebar a.active {
            background: #0d6efd;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .stat-card {
            border-radius: 10px;
            padding: 20px;
            color: white;
            text-align: center;
            margin-bottom: 20px;
        }
        .stat-card i {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        .recent-table {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="p-3 text-white">
            <h4><i class="fas fa-crown"></i> PhoneStore Admin</h4>
            <small>Xin chào, <?php echo $_SESSION['username']; ?></small>
        </div>
        
        <nav>
            <a href="index.php" class="active">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="products.php">
                <i class="fas fa-mobile-alt"></i> Sản phẩm
            </a>
            <a href="orders.php">
                <i class="fas fa-shopping-cart"></i> Đơn hàng
            </a>
            <a href="users.php">
                <i class="fas fa-users"></i> Người dùng
            </a>
            <a href="../index.php">
                <i class="fas fa-home"></i> Về trang chủ
            </a>
            <a href="../pages/logout.php" class="text-danger">
                <i class="fas fa-sign-out-alt"></i> Đăng xuất
            </a>
        </nav>
    </div>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
            <div class="text-muted">
                <?php echo date('d/m/Y H:i:s'); ?>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="row">
            <div class="col-md-3">
                <div class="stat-card" style="background: linear-gradient(135deg, #667eea, #764ba2);">
                    <i class="fas fa-users"></i>
                    <h3><?php echo $stats['users']; ?></h3>
                    <p>Người dùng</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card" style="background: linear-gradient(135deg, #f093fb, #f5576c);">
                    <i class="fas fa-mobile-alt"></i>
                    <h3><?php echo $stats['products']; ?></h3>
                    <p>Sản phẩm</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card" style="background: linear-gradient(135deg, #4facfe, #00f2fe);">
                    <i class="fas fa-shopping-cart"></i>
                    <h3><?php echo $stats['orders']; ?></h3>
                    <p>Đơn hàng</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card" style="background: linear-gradient(135deg, #43e97b, #38f9d7);">
                    <i class="fas fa-money-bill-wave"></i>
                    <h3><?php echo number_format($stats['revenue']); ?> đ</h3>
                    <p>Doanh thu</p>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="recent-table">
                    <h4><i class="fas fa-bolt"></i> Thao tác nhanh</h4>
                    <div class="row mt-3">
                        <div class="col-md-3 mb-2">
                            <a href="products.php?action=add" class="btn btn-primary w-100">
                                <i class="fas fa-plus"></i> Thêm sản phẩm
                            </a>
                        </div>
                        <div class="col-md-3 mb-2">
                            <a href="orders.php" class="btn btn-success w-100">
                                <i class="fas fa-eye"></i> Xem đơn hàng
                            </a>
                        </div>
                        <div class="col-md-3 mb-2">
                            <a href="users.php" class="btn btn-info w-100">
                                <i class="fas fa-user-plus"></i> Thêm người dùng
                            </a>
                        </div>
                        <div class="col-md-3 mb-2">
                            <a href="#" class="btn btn-warning w-100">
                                <i class="fas fa-chart-bar"></i> Báo cáo
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Orders -->
        <div class="row">
            <div class="col-md-8">
                <div class="recent-table">
                    <h4><i class="fas fa-clock"></i> Đơn hàng gần đây</h4>
                    <table class="table mt-3">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Khách hàng</th>
                                <th>Số tiền</th>
                                <th>Trạng thái</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT o.*, u.username 
                                    FROM orders o 
                                    JOIN users u ON o.user_id = u.id 
                                    ORDER BY o.created_at DESC 
                                    LIMIT 5";
                            $result = mysqli_query($conn, $sql);
                            
                            while($order = mysqli_fetch_assoc($result)):
                            ?>
                            <tr>
                                <td>#<?php echo $order['id']; ?></td>
                                <td><?php echo $order['username']; ?></td>
                                <td><?php echo number_format($order['total']); ?> đ</td>
                                <td>
                                    <span class="badge bg-warning"><?php echo $order['status']; ?></span>
                                </td>
                                <td>
                                    <a href="order_detail.php?id=<?php echo $order['id']; ?>" 
                                       class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- System Info -->
            <div class="col-md-4">
                <div class="recent-table">
                    <h4><i class="fas fa-info-circle"></i> Thông tin hệ thống</h4>
                    <ul class="list-group mt-3">
                        <li class="list-group-item">
                            <strong>PHP Version:</strong> <?php echo phpversion(); ?>
                        </li>
                        <li class="list-group-item">
                            <strong>Database:</strong> <?php echo DB_NAME; ?>
                        </li>
                        <li class="list-group-item">
                            <strong>Users Online:</strong> 1
                        </li>
                        <li class="list-group-item">
                            <strong>Memory Usage:</strong> 
                            <?php echo round(memory_get_usage() / 1024 / 1024, 2); ?> MB
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>