<?php
// products.php
session_start();
require_once '../includes/config.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../pages/login.php");
    exit();
}

// Lấy thống kê sản phẩm
$stats = [];
// Tổng sản phẩm
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM products");
$stats['total'] = mysqli_fetch_assoc($result)['total'];

// Sản phẩm còn hàng
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM products WHERE stock > 0");
$stats['in_stock'] = mysqli_fetch_assoc($result)['total'];

// Sản phẩm hết hàng
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM products WHERE stock = 0");
$stats['out_stock'] = mysqli_fetch_assoc($result)['total'];

// Sản phẩm mới trong tháng
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM products WHERE MONTH(created_at) = MONTH(CURDATE())");
$stats['new_this_month'] = mysqli_fetch_assoc($result)['total'];
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý sản phẩm - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin-banner.css">
    <style>
        /* Style hiện tại của bạn giữ nguyên */
    </style>
</head>
<body>
    <!-- Sidebar của bạn -->
    
    <div class="main-content">
        
        <!-- THÊM BANNER VÀO ĐÂY -->
        <div class="admin-banner banner-products">
            <div class="banner-bg-effect"></div>
            <div class="banner-content">
                <div class="banner-icon">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <div class="banner-text">
                    <h1 class="banner-title">Quản lý sản phẩm</h1>
                    <p class="banner-subtitle">Thêm, sửa, xóa và quản lý tất cả sản phẩm trong cửa hàng</p>
                    
                    <!-- Stats nhỏ trong banner -->
                    <div class="banner-stats">
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $stats['total']; ?></span>
                            <span class="stat-label">Tổng sản phẩm</span>
                        </div>
                        <div class="stat-item" style="background: rgba(40, 167, 69, 0.3);">
                            <span class="stat-value"><?php echo $stats['in_stock']; ?></span>
                            <span class="stat-label">Còn hàng</span>
                        </div>
                        <div class="stat-item" style="background: rgba(220, 53, 69, 0.3);">
                            <span class="stat-value"><?php echo $stats['out_stock']; ?></span>
                            <span class="stat-label">Hết hàng</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $stats['new_this_month']; ?></span>
                            <span class="stat-label">Mới tháng này</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Nút thêm sản phẩm -->
        <div class="mb-4">
            <a href="product_add.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Thêm sản phẩm mới
            </a>
        </div>
        
        <!-- Bảng sản phẩm -->
        <!-- ... phần code hiện tại của bạn ... -->
        
    </div>
</body>
</html>