<?php
// tvcs.php (hoặc orders.php)
session_start();
require_once '../includes/config.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../pages/login.php");
    exit();
}

// Lấy thống kê đơn hàng
$stats = [];
// Tổng đơn hàng
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM orders");
$stats['total'] = mysqli_fetch_assoc($result)['total'];

// Đơn hàng hôm nay
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM orders WHERE DATE(created_at) = CURDATE()");
$stats['today'] = mysqli_fetch_assoc($result)['total'];

// Đơn hàng chờ xử lý
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM orders WHERE status = 'pending'");
$stats['pending'] = mysqli_fetch_assoc($result)['total'];

// Đơn hàng đã giao
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM orders WHERE status = 'delivered'");
$stats['delivered'] = mysqli_fetch_assoc($result)['total'];

// Doanh thu hôm nay
$result = mysqli_query($conn, "SELECT SUM(total) as total FROM orders WHERE DATE(created_at) = CURDATE()");
$stats['revenue_today'] = mysqli_fetch_assoc($result)['total'] ?: 0;
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý đơn hàng - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin-banner.css">
    <style>
        /* Style hiện tại của bạn giữ nguyên */
    </style>
</head>
<body>
    <!-- Sidebar của bạn -->
    
    <div class="main-content">
        
        <!-- THÊM BANNER VÀO ĐÂY -->
        <div class="admin-banner banner-orders">
            <div class="banner-bg-effect"></div>
            <div class="banner-content">
                <div class="banner-icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div class="banner-text">
                    <h1 class="banner-title">Quản lý đơn hàng</h1>
                    <p class="banner-subtitle">Theo dõi và xử lý tất cả đơn hàng từ khách hàng</p>
                    
                    <!-- Stats nhỏ trong banner -->
                    <div class="banner-stats">
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $stats['total']; ?></span>
                            <span class="stat-label">Tổng đơn hàng</span>
                        </div>
                        <div class="stat-item" style="background: rgba(255, 193, 7, 0.3);">
                            <span class="stat-value"><?php echo $stats['pending']; ?></span>
                            <span class="stat-label">Chờ xử lý</span>
                        </div>
                        <div class="stat-item" style="background: rgba(40, 167, 69, 0.3);">
                            <span class="stat-value"><?php echo $stats['delivered']; ?></span>
                            <span class="stat-label">Đã giao</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value"><?php echo number_format($stats['revenue_today']); ?>đ</span>
                            <span class="stat-label">Doanh thu hôm nay</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Nội dung quản lý đơn hàng -->
        <!-- ... phần code hiện tại của bạn ... -->
        
    </div>
</body>
</html>