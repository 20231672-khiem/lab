<?php
// dashboard.php
session_start();
require_once '../includes/config.php';

// Kiểm tra đăng nhập
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../pages/login.php");
    exit();
}

// Lấy thống kê cho banner
$stats = [];
// Tổng sản phẩm
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM products");
$stats['total_products'] = mysqli_fetch_assoc($result)['total'];

// Tổng đơn hàng hôm nay
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM orders WHERE DATE(created_at) = CURDATE()");
$stats['today_orders'] = mysqli_fetch_assoc($result)['total'];

// Tổng doanh thu hôm nay
$result = mysqli_query($conn, "SELECT SUM(total) as total FROM orders WHERE DATE(created_at) = CURDATE()");
$stats['today_revenue'] = mysqli_fetch_assoc($result)['total'] ?: 0;

// Tổng người dùng mới hôm nay
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE DATE(created_at) = CURDATE()");
$stats['new_users'] = mysqli_fetch_assoc($result)['total'];
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin-banner.css">
    <style>
        /* Style hiện tại của bạn giữ nguyên */
    </style>
</head>
<body>
    <!-- Sidebar của bạn -->
    
    <!-- Main Content -->
    <div class="main-content">
        
        <!-- THÊM BANNER VÀO ĐÂY -->
        <div class="admin-banner banner-dashboard">
            <div class="banner-bg-effect"></div>
            <div class="banner-content">
                <div class="banner-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="banner-text">
                    <h1 class="banner-title">Xin chào, <?php echo $_SESSION['username']; ?>! 👋</h1>
                    <p class="banner-subtitle">Chào mừng bạn quay trở lại với hệ thống quản trị PhoneStore</p>
                    <div class="banner-date">
                        <i class="far fa-calendar-alt"></i>
                        <?php echo date('l, d/m/Y H:i'); ?>
                    </div>
                    
                    <!-- Stats nhỏ trong banner -->
                    <div class="banner-stats">
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $stats['total_products']; ?></span>
                            <span class="stat-label">Tổng sản phẩm</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $stats['today_orders']; ?></span>
                            <span class="stat-label">Đơn hàng hôm nay</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value"><?php echo number_format($stats['today_revenue']); ?>đ</span>
                            <span class="stat-label">Doanh thu hôm nay</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $stats['new_users']; ?></span>
                            <span class="stat-label">Người dùng mới</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Phần còn lại của dashboard -->
        <!-- ... -->
        
    </div>
</body>
</html>