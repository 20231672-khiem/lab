<?php
// admin/check_notifications.php
session_start();
require_once '../includes/config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

// Đếm đơn hàng mới
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM orders WHERE order_status = 'pending'");
$new_orders = mysqli_fetch_assoc($result)['count'];

// Đếm sản phẩm sắp hết hàng
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM products WHERE stock < 5 AND stock > 0");
$low_stock = mysqli_fetch_assoc($result)['count'];

// Đếm sản phẩm hết hàng
$result = mysqli_query($conn, "SELECT COUNT(*) as count FROM products WHERE stock = 0");
$out_of_stock = mysqli_fetch_assoc($result)['count'];

// Doanh thu hôm nay
$today = date('Y-m-d');
$result = mysqli_query($conn, "SELECT COALESCE(SUM(final_amount), 0) as total FROM orders WHERE DATE(created_at) = '$today' AND order_status = 'delivered'");
$today_revenue = mysqli_fetch_assoc($result)['total'];

echo json_encode([
    'success' => true,
    'new_orders' => $new_orders,
    'low_stock' => $low_stock,
    'out_of_stock' => $out_of_stock,
    'today_revenue' => $today_revenue,
    'timestamp' => time()
]);
?>