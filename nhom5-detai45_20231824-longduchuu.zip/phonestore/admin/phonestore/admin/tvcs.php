<?php
// admin/tvcs.php - Quản lý TVC
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    redirect('../pages/login.php');
}

// Xử lý thêm/sửa/xóa
$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        $title = cleanInput($_POST['title']);
        $video_url = cleanInput($_POST['video_url']);
        $youtube_id = cleanInput($_POST['youtube_id']);
        $description = cleanInput($_POST['description']);
        $sort_order = intval($_POST['sort_order']);
        
        if ($_POST['action'] == 'add') {
            $sql = "INSERT INTO tvcs (title, video_url, youtube_id, description, sort_order) 
                    VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ssssi", $title, $video_url, $youtube_id, $description, $sort_order);
            
            if (mysqli_stmt_execute($stmt)) {
                $message = '<div class="alert alert-success">✅ Thêm TVC thành công!</div>';
            }
        }
    }
}

// Xử lý xóa
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM tvcs WHERE id = $id");
    $message = '<div class="alert alert-success">✅ Đã xóa TVC!</div>';
}

// Lấy danh sách TVC
$tvcs = mysqli_query($conn, "SELECT * FROM tvcs ORDER BY sort_order ASC");
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý TVC - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar { min-height: 100vh; background: #343a40; position: fixed; width: 250px; }
        .sidebar a { color: white; text-decoration: none; padding: 15px 20px; display: block; border-bottom: 1px solid #495057; }
        .sidebar a:hover { background: #495057; }
        .sidebar a.active { background: #0d6efd; }
        .main-content { margin-left: 250px; padding: 20px; }
        .tvc-preview { width: 100%; height: 200px; object-fit: cover; border-radius: 8px; }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>
    
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1><i class="fas fa-video"></i> Quản lý TVC</h1>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTVCModal">
                <i class="fas fa-plus"></i> Thêm TVC mới
            </button>
        </div>
        
        <?php echo $message; ?>
        
        <!-- Danh sách TVC -->
        <div class="row">
            <?php while($tvc = mysqli_fetch_assoc($tvcs)): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <?php if($tvc['youtube_id']): ?>
                    <iframe width="100%" height="200" 
                            src="https://www.youtube.com/embed/<?php echo $tvc['youtube_id']; ?>" 
                            frameborder="0" allowfullscreen></iframe>
                    <?php else: ?>
                    <video width="100%" height="200" controls>
                        <source src="../assets/videos/<?php echo $tvc['video_url']; ?>" type="video/mp4">
                    </video>
                    <?php endif; ?>
                    
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $tvc['title']; ?></h5>
                        <p class="card-text"><?php echo $tvc['description']; ?></p>
                        <p class="text-muted small">
                            <i class="fas fa-eye"></i> <?php echo $tvc['views']; ?> lượt xem
                            <br>
                            <i class="fas fa-sort"></i> Thứ tự: <?php echo $tvc['sort_order']; ?>
                        </p>
                        
                        <div class="btn-group w-100">
                            <a href="edit_tvc.php?id=<?php echo $tvc['id']; ?>" class="btn btn-warning">
                                <i class="fas fa-edit"></i> Sửa
                            </a>
                            <a href="?delete=<?php echo $tvc['id']; ?>" 
                               class="btn btn-danger" 
                               onclick="return confirm('Xóa TVC này?')">
                                <i class="fas fa-trash"></i> Xóa
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
    
    <!-- Modal thêm TVC -->
    <div class="modal fade" id="addTVCModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Thêm TVC mới</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="mb-3">
                            <label>Tiêu đề TVC</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>
                        
                        <div class="mb-3">
                            <label>YouTube ID (ví dụ: KjCKx8LhZ28)</label>
                            <input type="text" name="youtube_id" class="form-control">
                            <small class="text-muted">Hoặc nhập URL video dưới đây</small>
                        </div>
                        
                        <div class="mb-3">
                            <label>URL Video</label>
                            <input type="url" name="video_url" class="form-control">
                        </div>
                        
                        <div class="mb-3">
                            <label>Mô tả</label>
                            <textarea name="description" class="form-control" rows="3"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label>Thứ tự</label>
                            <input type="number" name="sort_order" class="form-control" value="0">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                        <button type="submit" class="btn btn-primary">Thêm TVC</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>