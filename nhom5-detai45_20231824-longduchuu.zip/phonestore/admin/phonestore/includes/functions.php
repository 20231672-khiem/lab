<?php
// includes/functions.php

// Làm sạch dữ liệu nhập vào
function cleanInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Định dạng tiền Việt Nam
function formatPrice($price) {
    return number_format($price, 0, ',', '.') . ' đ';
}

// Chuyển hướng trang
function redirect($url) {
    header("Location: $url");
    exit();
}

?>
<?php
// includes/functions.php - Thêm các hàm này

// Format số điện thoại
function formatPhone($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    if (strlen($phone) == 10) {
        return substr($phone, 0, 4) . ' ' . substr($phone, 4, 3) . ' ' . substr($phone, 7, 3);
    }
    return $phone;
}

// Format thời gian
function timeAgo($timestamp) {
    $time_ago = strtotime($timestamp);
    $current_time = time();
    $time_difference = $current_time - $time_ago;
    $seconds = $time_difference;
    
    $minutes = round($seconds / 60);
    $hours = round($seconds / 3600);
    $days = round($seconds / 86400);
    $weeks = round($seconds / 604800);
    $months = round($seconds / 2629440);
    $years = round($seconds / 31553280);
    
    if ($seconds <= 60) {
        return "Vừa xong";
    } else if ($minutes <= 60) {
        return ($minutes == 1) ? "1 phút trước" : "$minutes phút trước";
    } else if ($hours <= 24) {
        return ($hours == 1) ? "1 giờ trước" : "$hours giờ trước";
    } else if ($days <= 7) {
        return ($days == 1) ? "Hôm qua" : "$days ngày trước";
    } else if ($weeks <= 4.3) {
        return ($weeks == 1) ? "1 tuần trước" : "$weeks tuần trước";
    } else if ($months <= 12) {
        return ($months == 1) ? "1 tháng trước" : "$months tháng trước";
    } else {
        return ($years == 1) ? "1 năm trước" : "$years năm trước";
    }
}

// Tạo slug từ chuỗi
function createSlug($string) {
    $string = preg_replace('/(á|à|ả|ã|ạ|ă|ắ|ằ|ẳ|ẵ|ặ|â|ấ|ầ|ẩ|ẫ|ậ)/', 'a', $string);
    $string = preg_replace('/(é|è|ẻ|ẽ|ẹ|ê|ế|ề|ể|ễ|ệ)/', 'e', $string);
    $string = preg_replace('/(í|ì|ỉ|ĩ|ị)/', 'i', $string);
    $string = preg_replace('/(ó|ò|ỏ|õ|ọ|ô|ố|ồ|ổ|ỗ|ộ|ơ|ớ|ờ|ở|ỡ|ợ)/', 'o', $string);
    $string = preg_replace('/(ú|ù|ủ|ũ|ụ|ư|ứ|ừ|ử|ữ|ự)/', 'u', $string);
    $string = preg_replace('/(ý|ỳ|ỷ|ỹ|ỵ)/', 'y', $string);
    $string = preg_replace('/(đ)/', 'd', $string);
    $string = preg_replace('/[^a-z0-9-]/', '-', strtolower($string));
    $string = preg_replace('/-+/', '-', $string);
    return trim($string, '-');
}

// Upload file
function uploadFile($file, $target_dir, $allowed_types = ['jpg', 'jpeg', 'png', 'gif']) {
    $target_file = $target_dir . basename($file["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    // Kiểm tra file ảnh
    $check = getimagesize($file["tmp_name"]);
    if ($check === false) {
        return ['success' => false, 'message' => 'File không phải là ảnh'];
    }
    
    // Kiểm tra định dạng
    if (!in_array($imageFileType, $allowed_types)) {
        return ['success' => false, 'message' => 'Chỉ chấp nhận JPG, JPEG, PNG, GIF'];
    }
    
    // Tạo tên file mới
    $new_filename = time() . '_' . uniqid() . '.' . $imageFileType;
    $new_filepath = $target_dir . $new_filename;
    
    if (move_uploaded_file($file["tmp_name"], $new_filepath)) {
        return ['success' => true, 'filename' => $new_filename];
    } else {
        return ['success' => false, 'message' => 'Có lỗi khi upload'];
    }
}

// Gửi email (đơn giản)
function sendEmail($to, $subject, $message) {
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= 'From: PhoneStore <noreply@phonestore.vn>' . "\r\n";
    
    return mail($to, $subject, $message, $headers);
}

// Tạo mã đơn hàng
function generateOrderCode() {
    return 'ORD' . date('Ymd') . rand(1000, 9999);
}

// Tính phần trăm giảm giá
function calculateDiscount($price, $sale_price) {
    if ($sale_price > 0 && $price > 0) {
        return round(($price - $sale_price) / $price * 100);
    }
    return 0;
}

// Kiểm tra quyền admin
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] == 'admin';
}

// Redirect với thông báo
function redirectWithMessage($url, $message, $type = 'success') {
    $_SESSION['flash_message'] = $message;
    $_SESSION['flash_type'] = $type;
    header("Location: $url");
    exit();
}

// Hiển thị thông báo flash
function displayFlashMessage() {
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        $type = $_SESSION['flash_type'] ?? 'info';
        unset($_SESSION['flash_message']);
        unset($_SESSION['flash_type']);
        
        $alert_class = [
            'success' => 'alert-success',
            'error' => 'alert-danger',
            'warning' => 'alert-warning',
            'info' => 'alert-info'
        ][$type] ?? 'alert-info';
        
        return "<div class='alert $alert_class alert-dismissible fade show'>
                    $message
                    <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                </div>";
    }
    return '';
}
?>